﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace eaglib
{
    public class Class1
    {
        public float UnityTest()
        {
            return 5.5f;
        }
    }
}
