﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
//using System.Threading.Tasks;

namespace UITest
{
    public class UItest : MonoBehaviour
    {
        public Button mybutton;
        public float UnityTest()
        {
            print(mybutton);
            return 5.5f;
        }
    }
}
