﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UIModule;
//using System.Threading.Tasks;

namespace UITest
{
    public class UItest2 : MonoBehaviour
    {
        public Button mybutton;
        public Canvas canvas;
        public Text tt;
        public float UnityTest()
        {
            if (tt.canvas==null)
            if (this.GetComponent<Transform>() != null) print(mybutton);
            return 5.5f;
        }
    }
}
